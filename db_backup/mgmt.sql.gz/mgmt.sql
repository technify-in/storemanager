-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 11, 2015 at 01:36 AM
-- Server version: 5.6.24-2+deb.sury.org~trusty+2
-- PHP Version: 5.5.9-1ubuntu4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `actionlog`
--

CREATE TABLE IF NOT EXISTS `actionlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `comment` varchar(255) NOT NULL,
  `table` varchar(64) NOT NULL,
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `actionlog`
--

INSERT INTO `actionlog` (`id`, `userid`, `datetime`, `comment`, `table`, `fieldid`, `type`) VALUES
(1, 1, '2014-01-13 21:35:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(2, 1, '2014-01-13 22:10:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(3, 1, '2014-01-13 22:10:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(4, 1, '2014-01-13 22:16:30', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(5, 1, '2014-01-13 22:17:29', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(6, 1, '2014-01-13 22:18:03', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(7, 1, '2014-01-13 22:19:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(8, 1, '2014-01-13 22:20:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(9, 1, '2014-01-13 22:20:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(10, 1, '2014-01-13 22:21:00', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(11, 1, '2014-01-13 22:21:04', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(12, 1, '2014-01-13 22:34:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(13, 1, '2014-01-13 22:34:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(14, 1, '2014-01-13 23:03:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(15, 1, '2014-01-13 23:03:05', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(16, 1, '2014-01-13 23:24:45', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(17, 1, '2014-01-13 23:24:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(18, 1, '2014-01-13 23:26:17', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(19, 1, '2014-01-13 23:27:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(20, 1, '2014-01-13 23:28:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(21, 1, '2014-01-13 23:28:43', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(22, 1, '2014-01-13 23:30:27', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(23, 1, '2014-01-13 23:30:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(24, 1, '2014-01-13 23:30:41', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(25, 1, '2014-01-13 23:30:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(26, 1, '2014-01-13 23:32:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(27, 1, '2014-01-13 23:32:56', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(28, 1, '2014-01-13 23:33:06', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(29, 1, '2014-01-13 23:34:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(30, 1, '2014-01-13 23:34:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(31, 1, '2014-01-13 23:39:27', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(32, 1, '2014-01-13 23:40:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(33, 1, '2014-01-13 23:40:40', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(34, 1, '2014-01-13 23:42:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(35, 1, '2014-01-13 23:42:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(36, 1, '2014-01-13 23:43:43', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(37, 1, '2014-01-13 23:43:47', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(38, 1, '2014-01-13 23:44:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(39, 1, '2014-01-13 23:44:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(40, 1, '2014-01-13 23:45:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(41, 1, '2014-01-13 23:46:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(42, 1, '2014-01-13 23:50:36', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(43, 1, '2014-01-13 23:50:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(44, 1, '2014-01-13 23:52:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(45, 1, '2014-01-13 23:52:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(46, 1, '2014-01-13 23:53:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(47, 1, '2014-01-13 23:53:13', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(48, 1, '2014-01-13 23:53:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(49, 1, '2014-01-13 23:53:45', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(50, 1, '2014-01-13 23:54:32', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(51, 1, '2014-01-13 23:54:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(52, 1, '2014-01-13 23:56:22', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(53, 1, '2014-01-13 23:56:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(54, 1, '2014-01-13 23:56:33', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(55, 1, '2014-01-13 23:56:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(56, 1, '2014-01-14 00:04:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(57, 1, '2014-01-14 00:04:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(58, 1, '2014-01-14 00:04:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(59, 1, '2014-01-14 00:14:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(60, 1, '2014-01-14 00:14:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(61, 1, '2014-01-14 00:23:35', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(62, 1, '2014-01-14 00:23:55', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(63, 1, '2014-01-14 00:24:05', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(64, 1, '2014-01-14 00:24:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(65, 1, '2014-01-14 00:24:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(66, 1, '2014-01-14 01:41:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(67, 1, '2014-01-14 01:41:59', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(68, 1, '2014-01-14 19:58:17', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(69, 1, '2014-01-14 19:58:44', 'Logout: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(70, 1, '2014-01-15 16:50:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(71, 1, '2014-01-15 16:52:08', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(72, 1, '2014-01-15 16:52:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(73, 1, '2014-01-15 16:53:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(74, 1, '2014-01-15 16:53:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(75, 1, '2014-01-15 16:53:31', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(76, 1, '2014-01-15 16:54:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(77, 1, '2014-01-15 18:42:23', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(78, 1, '2014-01-15 18:43:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(79, 1, '2014-01-15 18:56:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(80, 1, '2014-01-15 18:57:18', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(81, 1, '2014-01-17 10:44:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(82, 1, '2014-01-17 10:45:13', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(83, 1, '2014-01-17 10:45:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(84, 1, '2014-01-22 16:37:14', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(85, 1, '2014-01-22 16:38:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(86, 1, '2014-01-23 20:05:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(87, 1, '2014-02-02 17:37:38', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(88, 1, '2014-02-02 17:37:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(89, 1, '2014-02-02 23:34:56', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(90, 1, '2014-02-02 23:35:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(91, 1, '2014-02-02 23:42:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(92, 1, '2014-02-02 23:58:20', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(93, 1, '2014-02-03 00:08:17', 'Added feeder details for ', 'Villages', 1, 1),
(94, 1, '2014-02-03 01:28:51', 'Added new invoice ', 'Invoice', 1, 1),
(95, 1, '2014-02-04 21:46:08', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(96, 1, '2014-02-04 21:54:21', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(97, 1, '2014-02-04 22:03:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(98, 1, '2014-02-04 23:04:44', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(99, 1, '2014-02-04 23:05:03', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(100, 1, '2014-02-04 23:23:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(101, 1, '2014-02-04 23:23:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(102, 1, '2014-02-04 23:33:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(103, 1, '2014-02-04 23:36:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(104, 1, '2014-02-04 23:40:24', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(105, 1, '2014-02-04 23:40:35', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(106, 1, '2014-02-04 23:43:48', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(107, 1, '2014-02-04 23:43:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(108, 1, '2014-02-04 23:45:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(109, 1, '2014-02-04 23:45:11', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(110, 1, '2014-02-05 01:09:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(111, 1, '2014-02-05 01:09:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(112, 1, '2014-02-05 01:17:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(113, 1, '2014-02-05 01:18:02', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(114, 1, '2014-02-05 01:49:33', 'Added new invoice 100', 'Invoice', 1, 2),
(115, 1, '2014-02-05 01:50:23', 'Added new invoice 101', 'Invoice', 1, 3),
(116, 1, '2014-02-05 02:32:04', 'Added new invoice itemHTC One X', 'Stock Items', 1, 2),
(117, 1, '2014-02-05 02:33:51', 'Added new invoice itemiPhone 5S', 'Stock Items', 1, 3),
(118, 1, '2015-04-19 18:05:30', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(119, 1, '2015-04-19 18:17:32', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(120, 1, '2015-04-19 18:20:37', 'Added new invoice itemiPhone 5S 16GB Gold', 'Stock Items', 1, 4),
(121, 1, '2015-04-19 18:33:13', 'Added new invoice V68', 'Invoice', 1, 4),
(122, 1, '2015-04-19 18:41:22', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(123, 1, '2015-04-23 01:56:24', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(124, 1, '2015-04-23 03:13:54', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(125, 1, '2015-04-23 03:52:00', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(126, 1, '2015-04-23 14:49:50', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(127, 1, '2015-04-23 21:26:24', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4)', 'users', 1, 0),
(128, 1, '2015-04-25 03:57:32', 'Login: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(129, 1, '2015-04-25 04:13:33', 'Logout: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(130, 1, '2015-04-25 04:13:38', 'Login: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(131, 1, '2015-04-25 14:16:11', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(132, 1, '2015-04-27 04:52:41', 'Login: (IP: 124.253.58.105, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(133, 1, '2015-05-02 01:14:01', 'Login: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(134, 1, '2015-05-02 01:16:07', 'Added new Distributor BAMA Infotech', 'Distributors', 1, 2),
(135, 1, '2015-05-02 01:43:00', 'Login: (IP: 117.205.51.125, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(136, 1, '2015-05-02 01:56:31', 'Added new Distributor Dummy Distributor', 'Distributors', 1, 3),
(137, 1, '2015-05-02 02:09:15', 'Logout: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(138, 1, '2015-05-02 02:09:22', 'Login: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(139, 1, '2015-05-02 02:10:14', 'Added new invoice V101', 'Invoice', 1, 5),
(140, 1, '2015-05-02 02:17:59', 'Added new invoice itemiPhone 5S 16GB Gold', 'Stock Items', 1, 5),
(141, 1, '2015-05-02 02:29:52', 'Added new invoice itemiPhone 4S 8GB White', 'Stock Items', 1, 6),
(142, 1, '2015-05-02 11:52:17', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/7.1.5 Safari/537.85.14)', 'users', 1, 0),
(143, 1, '2015-05-02 23:58:31', 'Login: (IP: 124.253.139.247, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(144, 1, '2015-05-03 02:29:02', 'Login: (IP: 124.253.139.247, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(145, 1, '2015-05-03 16:34:34', 'Login: (IP: 117.205.63.162, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(146, 1, '2015-05-03 17:55:05', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(147, 1, '2015-05-04 17:14:30', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/7.1.5 Safari/537.85.14)', 'users', 1, 0),
(148, 1, '2015-05-06 02:06:44', 'Login: (IP: 124.253.137.38, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(149, 1, '2015-05-07 00:31:30', 'Login: (IP: 124.253.174.85, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(150, 1, '2015-05-07 23:59:40', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(151, 1, '2015-05-08 00:02:50', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(152, 1, '2015-05-08 01:10:56', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(153, 1, '2015-05-08 02:07:20', 'Logout: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(154, 1, '2015-05-08 10:58:50', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(155, 1, '2015-05-08 14:15:53', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(156, 1, '2015-05-08 14:16:40', 'Added new invoice P134', 'Invoice', 1, 121),
(157, 1, '2015-05-08 14:17:33', 'Added new invoice item', 'Stock Items', 1, 8),
(158, 1, '2015-05-08 14:18:25', 'Added new invoice P144', 'Invoice', 1, 122),
(159, 1, '2015-05-08 14:19:15', 'Added new invoice item', 'Stock Items', 1, 9),
(160, 1, '2015-05-08 14:19:27', 'Logout: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(161, 1, '2015-05-08 14:52:21', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(162, 1, '2015-05-08 16:07:02', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(163, 1, '2015-05-10 23:50:54', 'Login: (IP: 124.253.49.162, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(164, 1, '2015-05-15 00:49:33', 'Login: (IP: 124.253.167.243, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(165, 1, '2015-05-17 18:30:42', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(166, 1, '2015-05-17 18:50:46', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(167, 1, '2015-05-17 18:57:49', 'Added new invoice item', 'Stock Items', 1, 10),
(168, 1, '2015-05-17 20:21:10', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/7.1.6 Safari/537.85.15)', 'users', 1, 0),
(169, 1, '2015-05-17 20:52:10', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(170, 1, '2015-05-18 18:32:11', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/7.1.6 Safari/537.85.15)', 'users', 1, 0),
(171, 1, '2015-05-19 14:27:29', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(172, 1, '2015-05-20 21:54:47', 'Login: (IP: 1.39.33.82, User Agent: Mozilla/5.0 (Android; Mobile; rv:38.0) Gecko/38.0 Firefox/38.0)', 'users', 1, 0),
(173, 1, '2015-05-21 17:49:06', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(174, 1, '2015-05-24 11:49:42', 'Login: (IP: 124.253.58.202, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17)', 'users', 1, 0),
(175, 1, '2015-05-24 23:55:23', 'Login: (IP: 124.253.180.18, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17)', 'users', 1, 0),
(176, 1, '2015-05-24 23:55:30', 'Login: (IP: 124.253.180.18, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17)', 'users', 1, 0),
(177, 1, '2015-05-25 00:00:29', 'Login: (IP: 124.253.180.18, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(178, 1, '2015-05-26 09:37:53', 'Login: (IP: 124.253.237.115, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(179, 1, '2015-05-26 10:38:55', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(180, 1, '2015-05-26 13:27:33', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(181, 1, '2015-05-26 20:00:42', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(182, 1, '2015-05-26 22:39:35', 'Login: (IP: 124.253.127.81, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(183, 1, '2015-05-27 14:22:12', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(184, 1, '2015-05-27 23:14:41', 'Login: (IP: 124.253.243.109, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(185, 1, '2015-05-29 10:16:41', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(186, 1, '2015-05-29 15:07:23', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(187, 1, '2015-05-30 16:03:39', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(188, 1, '2015-05-30 23:40:28', 'Login: (IP: 124.253.57.234, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(189, 1, '2015-05-31 09:50:13', 'Login: (IP: 124.253.57.234, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(190, 1, '2015-06-01 18:00:58', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(191, 1, '2015-06-01 20:03:00', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(192, 1, '2015-06-02 18:03:40', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(193, 1, '2015-06-03 00:38:25', 'Login: (IP: 124.253.58.21, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(194, 1, '2015-06-03 00:41:16', 'Added new invoice itemLightning to USB Cable', 'Stock Items', 1, 12),
(195, 1, '2015-06-04 17:33:22', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(196, 1, '2015-06-05 16:32:33', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(197, 1, '2015-06-06 23:39:35', 'Login: (IP: 124.253.139.178, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(198, 1, '2015-06-08 16:43:27', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(199, 1, '2015-06-08 18:50:56', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(200, 1, '2015-06-09 14:24:02', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(201, 1, '2015-06-15 12:39:55', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(202, 1, '2015-06-15 13:55:46', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0)', 'users', 1, 0),
(203, 1, '2015-06-15 14:01:20', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(204, 1, '2015-06-15 15:57:52', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3)', 'users', 1, 0),
(205, 1, '2015-06-15 16:01:59', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0)', 'users', 1, 0),
(206, 1, '2015-06-15 17:51:10', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0)', 'users', 1, 0),
(207, 1, '2015-06-17 19:12:32', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/43.0.2357.81 Chrome/43.0.2357.81 Safari/537.36)', 'users', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `distributorinvoices`
--

CREATE TABLE IF NOT EXISTS `distributorinvoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `distributorid` int(10) unsigned NOT NULL,
  `invoicenumber` varchar(20) NOT NULL,
  `invoicedate` date NOT NULL,
  `description` text NOT NULL,
  `noofitems` int(10) unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `distributorid` (`distributorid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=391 ;

--
-- Dumping data for table `distributorinvoices`
--

INSERT INTO `distributorinvoices` (`id`, `distributorid`, `invoicenumber`, `invoicedate`, `description`, `noofitems`, `amount`, `modified`, `modifiedby`) VALUES
(1, 1, 'V1', '2014-04-02', '1 x iPod Shuffle', 1, 3426.00, '2014-02-03 01:28:50', 0),
(2, 1, 'V11', '2014-04-02', '2 x 5S 16GB Gold\r\n2 x 5S 16GB Space Gray', 4, 205768.00, '2014-02-05 01:49:33', 0),
(3, 1, 'V8', '2014-04-02', '1 x iPad Mini WiFi + Cell 16GB White', 1, 29712.00, '2014-02-05 01:50:22', 0),
(4, 1, 'V69', '2014-04-19', '2 x 4S White', 2, 60576.00, '2015-04-19 18:33:13', 0),
(5, 1, 'V101', '2014-05-01', '1 x iPhone 5S', 1, 51442.00, '2015-05-02 02:10:14', 0),
(6, 1, '80', '2013-05-17', '2 x iPhone 4 8GB White\r2 x iPhone 4 8GB Black', 4, 101924.00, '0000-00-00 00:00:00', 0),
(7, 1, '123', '2013-05-30', '1 x iPhone 5 16GB Black\r\n1 x iPhone 5 16GB Silver', 2, 87500.00, '0000-00-00 00:00:00', 0),
(8, 1, '124', '2013-05-30', '1 x iPad Retina Wifi + Cell 16GB Black\r\n1 x iPad Retina Wifi + Cell 16GB Silver', 2, 66609.00, '0000-00-00 00:00:00', 0),
(9, 1, '125', '2013-05-30', '5 x EarPods', 5, 9164.98, '0000-00-00 00:00:00', 0),
(10, 1, '131', '2013-06-01', '1 x iPhone 5 16GB White\r2 x iPhone 4 8GB Black', 3, 94712.00, '0000-00-00 00:00:00', 0),
(11, 1, '135', '2013-06-05', '2 x iPhone 4 8GB White\r1 x iPhone 5 16GB Silver', 3, 94712.00, '0000-00-00 00:00:00', 0),
(30, 1, '152', '2013-06-11', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(31, 1, '158', '2013-06-13', '1 x iPhone 4 8GB Black\n1 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(32, 1, '170', '2013-06-17', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(33, 1, '175', '2013-06-18', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(34, 1, '191', '2013-06-21', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(35, 1, '199', '2013-06-24', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(36, 1, '230', '2013-07-03', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(37, 1, '241', '2013-07-06', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(38, 1, '242', '2013-07-06', '1 x iPad Mini 16GB WiFi White', 1, 21024.00, '0000-00-00 00:00:00', 0),
(39, 1, '243', '2013-07-06', '2 x EarPods', 2, 3666.00, '0000-00-00 00:00:00', 0),
(40, 1, '245', '2013-07-06', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(41, 1, '252', '2013-07-09', '3 x iPhone 4 8GB Black\n4 x iPhone 4 8GB White', 7, 178367.00, '0000-00-00 00:00:00', 0),
(42, 1, '271', '2013-07-09', '2 x iPhone 4 16GB White', 2, 61154.00, '0000-00-00 00:00:00', 0),
(43, 1, '273', '2013-07-09', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(44, 1, '312', '2013-07-09', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(45, 1, '315', '2013-07-09', '1 x iPad Mini 16GB WiFi Black', 1, 21024.00, '0000-00-00 00:00:00', 0),
(46, 1, '316', '2013-07-09', 'iPad 4 16GB WiFi Black Demo', 1, 24244.00, '0000-00-00 00:00:00', 0),
(47, 1, '322', '2013-07-25', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(48, 1, '332', '2013-07-27', 'iPad 4 16GB WiFi White', 1, 30305.00, '0000-00-00 00:00:00', 0),
(49, 1, '343', '2013-07-31', '1 x iPhone 5 16GB Black\n1 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(50, 1, '344', '2013-07-31', '1 x iPhone 4 16GB Black', 1, 30577.00, '0000-00-00 00:00:00', 0),
(51, 1, '351', '2013-08-02', '6 x Apple TV', 6, 38170.00, '0000-00-00 00:00:00', 0),
(52, 1, '371', '2013-08-05', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(53, 1, '400', '2013-08-09', '2 x iPhone 5 16GB White\n1 x iPhone 4 8GB Black', 3, 112981.00, '0000-00-00 00:00:00', 0),
(54, 1, '408', '2013-08-10', '1 x iPhone 4 16GB White', 1, 61154.00, '0000-00-00 00:00:00', 0),
(55, 1, '429', '2013-08-14', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(56, 1, '449', '2013-08-19', '1 x iPhone 5 16GB white', 1, 43750.00, '0000-00-00 00:00:00', 0),
(57, 1, '476', '2013-08-23', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(58, 1, '503', '2013-08-31', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(59, 1, '507', '2013-08-31', '1 x iPhone 5 16GB White', 1, 43750.00, '0000-00-00 00:00:00', 0),
(60, 1, '508', '2013-08-31', '1 x iPad 4 16GB WiFi White', 1, 30305.00, '0000-00-00 00:00:00', 0),
(61, 1, '523', '2013-08-31', '1 x iPhone 4 8GB Black', 1, 25481.00, '0000-00-00 00:00:00', 0),
(62, 1, '530', '2013-09-05', '1 x iPhone 5 16GB White', 1, 43750.00, '0000-00-00 00:00:00', 0),
(63, 1, '587', '2013-09-17', '1 x iPad 4 WiFi + Cellular 32GB Black', 1, 43605.01, '0000-00-00 00:00:00', 0),
(64, 1, '620', '2013-09-25', '5 x Lightning Cable', 5, 6404.97, '0000-00-00 00:00:00', 0),
(65, 1, '664', '2013-10-16', '1 x Apple Protection Plan', 1, 3514.00, '0000-00-00 00:00:00', 0),
(66, 1, '687', '2013-10-26', '7 x Lightning Cable', 7, 8966.96, '0000-00-00 00:00:00', 0),
(67, 1, '708', '2013-11-02', '2 x iPhone 5C 16GB Blue\n2 x iPhone 5C 16GB White\n2 x iPhone 5S 32GB Space Gray', 6, 281344.00, '0000-00-00 00:00:00', 0),
(68, 1, '760', '2013-11-02', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(69, 1, '788', '2013-11-18', '1 x iPhone 5S 16GB Space Gray\n1 x iPhone 5S 16GB Silver', 2, 102884.00, '0000-00-00 00:00:00', 0),
(70, 1, '799', '2013-11-19', '3 x Apple Protection Plan', 3, 10542.00, '0000-00-00 00:00:00', 0),
(71, 1, '828', '2013-11-23', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(72, 1, '849', '2013-11-23', '3 x iPhone 5S Case', 3, 8421.01, '0000-00-00 00:00:00', 0),
(73, 1, '871', '2013-11-29', '2 x EarPods\n4 x iPhone 5C Case', 6, 12108.00, '0000-00-00 00:00:00', 0),
(74, 1, '873', '2013-11-30', '3 x iPad 4 WiFi + Cell 16GB White\n3 x iPad 4 WiFi 16GB Black', 6, 207114.00, '0000-00-00 00:00:00', 0),
(75, 1, '882', '2013-11-30', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(76, 1, '891', '2013-12-03', '1 X iPhone 4S 8GB White', 1, 30288.00, '0000-00-00 00:00:00', 0),
(77, 1, '902', '2013-12-05', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(78, 1, '938', '2013-12-09', '3 x iPhone 5S 16GB Gold', 3, 154326.00, '0000-00-00 00:00:00', 0),
(79, 1, '1103', '2013-12-26', '2 x iPhone 5S 16GB Gold', 2, 102884.00, '0000-00-00 00:00:00', 0),
(80, 1, '1178', '2014-01-22', '1 x iPhone 5S 16GB Silver\n2 x iPhone 5S 16GB Space Gray', 3, 154326.00, '0000-00-00 00:00:00', 0),
(81, 1, '1198', '2014-01-23', '1 x iPhone 4S 8GB White\n2 x iPhone 4S 8GB Black\n1 x iPhone 5S 16GB Gold', 4, 125767.99, '0000-00-00 00:00:00', 0),
(82, 1, '1210', '2014-01-25', '1 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black\n4 x iPhone 5S 16GB Gold', 6, 266344.00, '0000-00-00 00:00:00', 0),
(83, 1, '1233', '2014-01-28', '6 x iPhone 4 8GB White\n4 x iPhone 4S 8GB White\n2 x iPhone 4S 8GB Black', 12, 313842.00, '0000-00-00 00:00:00', 0),
(84, 1, '1254', '2014-02-01', '5 x iPhone 4 8GB Black\n7 x iPhone 4 8GB White', 12, 264228.00, '0000-00-00 00:00:00', 0),
(85, 1, '1264', '2014-02-01', '4 x USB Power Adapter', 4, 5124.00, '0000-00-00 00:00:00', 0),
(86, 1, '1274', '2014-02-03', '10 x Lightning Cables', 10, 13160.05, '0000-00-00 00:00:00', 0),
(87, 1, '1318', '2014-02-10', '2 x iPhone 5S 16GB Silver', 2, 102884.00, '0000-00-00 00:00:00', 0),
(88, 1, '1331', '2014-02-14', '1 x iPhone 5S 16GB Silver', 1, 51442.00, '0000-00-00 00:00:00', 0),
(89, 1, '1342', '2014-02-15', '1 x iPhone 5C 16GB Pink', 1, 40288.00, '0000-00-00 00:00:00', 0),
(90, 1, '1353', '2014-02-15', '2 x iPhone 5S 16GB Gold\n2 x iPhone 5S 16GB Silver\n2 x iPhone 5S 16GB Space Gray', 6, 308652.00, '0000-00-00 00:00:00', 0),
(91, 1, '1360', '2014-02-15', '5 x USB Power Adapter', 5, 6404.97, '0000-00-00 00:00:00', 0),
(92, 1, '1367', '2014-02-19', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(93, 1, '1369', '2014-02-19', '1 x iPad Air 16GB WiFi + Cell Silver\n1 x iPad Mini 16GB WiFi Silver\n1 x iPad Mini 16GB WiFi + Cell Silver', 3, 93943.00, '0000-00-00 00:00:00', 0),
(94, 1, '1386', '2014-02-22', '2 x iPhone 5S 16GB Gold\n2 x iPhone 5S 16GB Silver', 4, 205768.00, '0000-00-00 00:00:00', 0),
(95, 1, '1395', '2014-02-26', '8 x iPhone 5S 16GB Gold', 8, 411536.00, '0000-00-00 00:00:00', 0),
(96, 1, '1403', '2014-02-26', '1 x iPhone 5S Case Black', 1, 5614.00, '0000-00-00 00:00:00', 0),
(97, 1, '1408', '2014-02-26', '1 x iPhone 5C 16GB White\n2 x iPhone 4S 8GB Black\n1 x iPhone 4S 8GB White\n1 x iPhone 5S 16GB Gold', 5, 182594.00, '0000-00-00 00:00:00', 0),
(98, 1, '1410', '2014-03-01', '1 x iPhone 5S 16GB Silver Demo', 1, 34930.00, '0000-00-00 00:00:00', 0),
(99, 1, '1414', '2014-03-01', '1 x iPad Mini 16GB WiFi Space Gray', 1, 42116.00, '0000-00-00 00:00:00', 0),
(100, 1, '1425', '2014-03-03', '1 x iPad 4 16GB WiFi + Cell Black', 1, 38365.00, '0000-00-00 00:00:00', 0),
(101, 1, '1426', '2014-03-03', '1 x iPad Mini RD 16GB WiFi + Cell Silver', 1, 36442.00, '0000-00-00 00:00:00', 0),
(102, 1, '1438', '2014-03-03', '2 x iPhone 5S 16GB Space Gray', 2, 102884.00, '0000-00-00 00:00:00', 0),
(103, 1, '1439', '2014-03-03', '1 x iPad Mini 16GB WiFi + Cell Silver', 1, 29712.00, '0000-00-00 00:00:00', 0),
(104, 1, '1440', '2014-03-03', '7 x Lightning Cable', 7, 9212.00, '0000-00-00 00:00:00', 0),
(105, 1, '1444', '2014-03-03', '1 x iPhone 5C 16GB Yellow', 1, 40288.00, '0000-00-00 00:00:00', 0),
(106, 1, '1445', '2014-03-03', '1 x iPod Shuffle 2GB Pink\n1 x iPod Shuffle 2GB Silver', 2, 6852.00, '0000-00-00 00:00:00', 0),
(107, 1, '1447', '2014-03-03', '2 x iPhone 5S 16GB Gold', 2, 102884.00, '0000-00-00 00:00:00', 0),
(108, 1, '1461', '2014-03-03', '10 x Apple Protection Plan', 10, 35140.00, '0000-00-00 00:00:00', 0),
(109, 1, '1471', '2014-03-03', '1 x iPhone 5S 64GB Silver', 1, 68750.00, '0000-00-00 00:00:00', 0),
(110, 1, '1477', '2014-03-13', '1 x iPad Air 16GB WiFi + Cell Silver', 1, 43173.00, '0000-00-00 00:00:00', 0),
(111, 1, '1478', '2014-03-13', '1 x iPod Shuffle 2GB Space Gray\n1 x iPod Shuffle 2GB Green\n1 x iPod Shuffle 2GB Yellow', 3, 10278.00, '0000-00-00 00:00:00', 0),
(112, 1, '1494', '2014-03-13', '20 x Lightning Cable\n1 x 5C Dock\n1 x 5S Dock\n3 x 5S Case', 25, 30356.09, '0000-00-00 00:00:00', 0),
(113, 1, '1496', '2014-03-13', '1 x iPad Mini 16GB WiFi + Cell Silver', 1, 29712.10, '0000-00-00 00:00:00', 0),
(114, 1, '1508', '2014-03-20', '1 x iPad Air 16GB WiFi Silver', 1, 34519.24, '0000-00-00 00:00:00', 0),
(115, 1, '1511', '2014-03-20', '5 x USB Power Adapter\n1 x 30 Pin Adapter', 6, 8237.97, '0000-00-00 00:00:00', 0),
(116, 1, '1527', '2014-03-26', '2 x iPad Mini 16GB WiFi Silver', 2, 42115.99, '0000-00-00 00:00:00', 0),
(117, 1, '1533', '2014-03-28', '2 x iPhone 5S 16GB Space Gray\n1 x iPhone 4S 8GB White', 3, 133172.00, '0000-00-00 00:00:00', 0),
(118, 1, '1534', '2014-03-28', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(120, 1, '891', '2013-12-03', '1 X iPhone 4S 8GB White', 1, 30288.00, '0000-00-00 00:00:00', 0),
(121, 1, 'P134', '2015-05-05', '1 x iPhone 6 64GB Silver', 1, 62500.00, '2015-05-08 14:16:40', 0),
(122, 1, 'P144', '2015-05-07', '1 x iPhone 6 16GB Gold', 1, 53846.00, '2015-05-08 14:18:25', 0),
(124, 1, 'V1', '2014-04-02', '1 x iPod Shuffle 2GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(125, 1, 'V8', '2014-04-02', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(126, 1, 'V11', '2014-04-02', '', 4, 0.00, '0000-00-00 00:00:00', 0),
(127, 1, 'V17', '2014-04-04', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(128, 1, 'V19', '2014-04-04', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(129, 1, 'V20', '2014-04-04', '12 x Lightning Cable', 12, 0.00, '0000-00-00 00:00:00', 0),
(130, 1, 'V22', '2014-04-05', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(131, 1, 'V23', '2014-04-05', '', 5, 0.00, '0000-00-00 00:00:00', 0),
(132, 1, 'V24', '2014-04-05', '13 x Apple Protection Plan', 13, 0.00, '0000-00-00 00:00:00', 0),
(133, 1, 'V29', '2014-04-07', '', 10, 0.00, '0000-00-00 00:00:00', 0),
(134, 1, 'V30', '2014-04-07', '1 x iPod Nano 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(135, 1, 'V34', '2014-04-08', '', 3, 0.00, '0000-00-00 00:00:00', 0),
(136, 1, 'V37', '2014-04-08', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(137, 1, 'V41', '2014-04-08', '40 x Lightning Cables', 40, 0.00, '0000-00-00 00:00:00', 0),
(138, 1, 'V42', '2014-04-08', '1 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black', 2, 0.00, '0000-00-00 00:00:00', 0),
(139, 1, 'V50', '2014-04-14', '1 x iPhone 5S Dock', 1, 0.00, '0000-00-00 00:00:00', 0),
(140, 1, 'V51', '2014-04-14', '1 x iPhone 5S 16GB Gold\n1 x iPhone 5S 32GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(141, 1, 'V52', '2014-04-14', '1 x iPhone 5S 16GB Gold\n1 x iPhone 5S 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(142, 1, 'V58', '2014-04-14', '5 x iPhone 5S 16GB Space Gray', 5, 0.00, '0000-00-00 00:00:00', 0),
(143, 1, 'V62', '2014-04-14', '2 x iPhone 5S 16GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(144, 1, 'V69', '2014-04-14', '2 x iPhone 4S 8GB', 2, 0.00, '0000-00-00 00:00:00', 0),
(145, 1, 'V70', '2014-04-14', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(146, 1, 'V71', '2014-04-14', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(147, 1, 'V75', '2014-04-14', '', 9, 0.00, '0000-00-00 00:00:00', 0),
(148, 1, 'V79', '2014-04-23', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(149, 1, 'V86', '2014-04-23', '2 x Apple Protection Plan iPad', 2, 0.00, '0000-00-00 00:00:00', 0),
(150, 1, 'V101', '2014-05-01', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(151, 1, 'V112', '2014-05-03', '1 x iPhone 5S 16GB Silver\n1 x iPhone 4S 8GB White', 2, 0.00, '0000-00-00 00:00:00', 0),
(152, 1, 'V114', '2014-05-03', '1 x iPod Shuffle 2GB Blue', 1, 0.00, '0000-00-00 00:00:00', 0),
(153, 1, 'V117', '2014-05-05', '1 x iPhone 4S 8GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(154, 1, 'V119', '2014-05-05', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(155, 1, 'V121', '2014-05-06', '1 x iPhone 4S 8GB White\n4 x iPhone 5S 16GB Gold', 5, 0.00, '0000-00-00 00:00:00', 0),
(156, 1, 'V130', '2014-05-07', '2 x iPhone 4S 8GB White', 2, 0.00, '0000-00-00 00:00:00', 0),
(157, 1, 'V140', '2014-05-08', '1 x iPhone 4S 8GB Black\n4 x iPhone 4S 8GB White', 5, 0.00, '0000-00-00 00:00:00', 0),
(158, 1, 'V156', '2014-05-08', '1 x iPhone 5S 16GB Gold\n1 x iPhone 5S 16GB Silver', 2, 0.00, '0000-00-00 00:00:00', 0),
(159, 1, 'V164', '2014-05-14', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(160, 1, 'V171', '2014-05-14', '1 x iPhone 5C 16GB Blue Demo', 1, 0.00, '0000-00-00 00:00:00', 0),
(161, 1, 'V172', '2014-05-16', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(162, 1, 'V183', '2014-05-16', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(163, 1, 'V186', '2014-05-16', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(164, 1, 'V189', '2014-05-16', '', 3, 0.00, '0000-00-00 00:00:00', 0),
(165, 1, 'V191', '2014-05-16', '1 x iPod Nano 16GB Space Gray\n1 x iPod Shuffle 2Gb Blue', 2, 0.00, '0000-00-00 00:00:00', 0),
(166, 1, 'V196', '2014-05-16', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(167, 1, 'V200', '2014-05-16', '1 x iPod Shuffle 2GB Pink', 1, 0.00, '0000-00-00 00:00:00', 0),
(168, 1, 'V202', '2014-05-16', '', 14, 0.00, '0000-00-00 00:00:00', 0),
(169, 1, 'V205', '2014-05-16', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(170, 1, 'V206', '2014-05-24', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(171, 1, 'V208', '2014-05-24', '', 5, 0.00, '0000-00-00 00:00:00', 0),
(172, 1, 'V217', '2014-05-29', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(173, 1, 'V218', '2014-05-29', '', 14, 0.00, '0000-00-00 00:00:00', 0),
(174, 1, 'V231', '2014-06-02', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(175, 1, 'V236', '2014-06-02', '', 3, 0.00, '0000-00-00 00:00:00', 0),
(176, 1, 'V248', '2014-06-02', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(177, 1, 'V256', '2014-06-07', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(178, 1, 'V261', '2014-06-09', '2 x iPhone 4S 8GB', 2, 0.00, '0000-00-00 00:00:00', 0),
(179, 1, 'V263', '2014-06-09', '', 12, 0.00, '0000-00-00 00:00:00', 0),
(180, 1, 'V264', '2014-06-10', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(181, 1, 'V275', '2014-06-10', '1 x iPhone 4S 8GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(182, 1, 'V282', '2014-06-14', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(183, 1, 'V284', '2014-06-14', '20 x Lightning Cable', 20, 0.00, '0000-00-00 00:00:00', 0),
(184, 1, 'V289', '2014-06-16', '1 x iPhone 4S 8GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(185, 1, 'V294', '2014-06-16', '', 10, 0.00, '0000-00-00 00:00:00', 0),
(186, 1, 'V302', '2014-06-16', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(187, 1, 'V313', '2014-06-16', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(188, 1, 'V318', '2014-06-20', '1 x iPhone 4S 8GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(189, 1, 'V324', '2014-06-21', '', 4, 0.00, '0000-00-00 00:00:00', 0),
(190, 1, 'V329', '2014-06-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(191, 1, 'V333', '2014-06-23', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(192, 1, 'V335', '2014-06-23', '', 2, 0.00, '0000-00-00 00:00:00', 0),
(193, 1, 'V340', '2014-06-24', '', 5, 0.00, '0000-00-00 00:00:00', 0),
(194, 1, 'V346', '2014-06-27', '5 x 30 Pin to USB Cable', 5, 0.00, '0000-00-00 00:00:00', 0),
(195, 1, 'V354', '2014-06-28', '1 x iPhone 5S 32GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(196, 1, 'V355', '2014-06-28', '1 x iPhone 4 8GB Black\n5 x iPhone 5S 16GB Gold', 6, 0.00, '0000-00-00 00:00:00', 0),
(197, 1, 'V358', '2014-06-28', '1 x iPhone 4S 8GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(198, 1, 'V366', '2014-06-28', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(199, 1, 'V368', '2014-06-28', '1 x iPad Mini WiFi 16Gb Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(200, 1, 'V371', '2014-07-01', '1 x iPhone 5C 8GB Pink', 1, 0.00, '0000-00-00 00:00:00', 0),
(201, 1, 'V373', '2014-07-01', '1 x iPhone 4 8Gb Black', 1, 0.00, '0000-00-00 00:00:00', 0),
(202, 1, 'V375', '2014-07-03', '10 x Lightning to USB cable', 10, 0.00, '0000-00-00 00:00:00', 0),
(203, 1, 'V383', '2014-07-04', '1 x iPod Nano 16GB Blue', 1, 0.00, '0000-00-00 00:00:00', 0),
(204, 1, 'V396', '2014-07-05', '5 x iPhone 4S 8Gb White', 5, 0.00, '0000-00-00 00:00:00', 0),
(205, 1, 'V399', '2014-07-08', '1 x iPad Mini RD WiFi + Cell 32GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(206, 1, 'V409', '2014-07-12', '15 x Lightning to USB Cable', 15, 0.00, '0000-00-00 00:00:00', 0),
(207, 1, 'V424', '2014-07-15', '1 x iPhone 5S 16GB Gold\n2 x iPhone 4S 8Gb White', 3, 0.00, '0000-00-00 00:00:00', 0),
(208, 1, 'V425', '2014-07-15', '1 x Apple Protection Plan', 1, 0.00, '0000-00-00 00:00:00', 0),
(209, 1, 'V435', '2014-07-17', '1 x iPod Classic 160GB Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(210, 1, 'V441', '2014-07-17', '1 x iPhone 5S 16GB', 1, 0.00, '0000-00-00 00:00:00', 0),
(211, 1, 'V443', '2014-07-19', '10 x USB Power Adapter', 10, 0.00, '0000-00-00 00:00:00', 0),
(212, 1, 'V448', '2014-07-19', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(213, 1, 'V450', '2014-07-19', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(214, 1, 'V451', '2014-07-21', '', 1, 0.00, '0000-00-00 00:00:00', 0),
(215, 1, 'V457', '2014-07-22', '', 3, 0.00, '0000-00-00 00:00:00', 0),
(216, 1, 'V461', '2014-07-22', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(217, 1, 'V465', '2014-07-24', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(218, 1, 'V471', '2014-07-28', '1 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black\n1 x iPhone 5C White\n1 x iPhone 5C Pink\n2 x iPhone 5S 16GB Gold\n1 x iPhone 5S 16GB Silver\n1 x iPhone 5S 16GB Space Gray', 8, 0.00, '0000-00-00 00:00:00', 0),
(219, 1, 'V473', '2014-07-28', '1 x iPod Nano 16GB Green', 1, 0.00, '0000-00-00 00:00:00', 0),
(220, 1, 'V479', '2014-07-28', '1 x iPad Mini WiFi 16Gb Space Gray\n1 x iPad Mini WiFi 16Gb Silver', 2, 0.00, '0000-00-00 00:00:00', 0),
(221, 1, 'V481', '2014-07-28', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(222, 1, 'V482', '2014-07-28', '1 x iPod Nano 16GB Space Gray\n2 x iPod Shuffle 2Gb Purple\n2 x iPod Shuffle 2Gb Space Gray', 5, 0.00, '0000-00-00 00:00:00', 0),
(223, 1, 'V489', '2014-08-01', '3 x iPhone 5S 16GB Gold\n2 x iPhone 4S 8GB Black\n2 x iPhone 4S 8GB White', 7, 0.00, '0000-00-00 00:00:00', 0),
(224, 1, 'V491', '2014-08-01', '3 x EarPods\n15 x Lightning Cables', 18, 0.00, '0000-00-00 00:00:00', 0),
(225, 1, 'V499', '2014-08-04', '1 x iPhone 4S 8GB Black', 1, 0.00, '0000-00-00 00:00:00', 0),
(226, 1, 'V505', '2014-08-06', '2 x iPhone 4S 8GB Black', 2, 0.00, '0000-00-00 00:00:00', 0),
(227, 1, 'V513', '2014-08-07', '1 x iPhone 5C 8Gb White', 1, 0.00, '0000-00-00 00:00:00', 0),
(228, 1, 'V520', '2014-08-07', '1 x iPad Mini RD WiFi 16GB Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(229, 1, 'V525', '2014-08-07', '4 x iPhone 4s 8Gb Black\n6 x iPhone 4s 8Gb White\n1 x iPhone 5C 8Gb White\n2 x iPhone 5S 16Gb Gold\n1 x iPhone 5S 16GB Space Gray\n', 14, 0.00, '0000-00-00 00:00:00', 0),
(230, 1, 'V527', '2014-08-07', '1 x iPad Air WiFi 16GB Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(231, 1, 'V532', '2014-08-07', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(232, 1, 'V533', '2014-08-18', '1 x iPad Air WiFi 16Gb Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(233, 1, 'V538', '2014-08-18', '16 x iPod Shuffle 2GB Blue\n17 x iPod Shuffle 2GB Purple\n6 x iPod Shuffle 2GB Space Gray\n1 x iPod Shuffle 2GB Green\n\n', 40, 0.00, '0000-00-00 00:00:00', 0),
(234, 1, 'V539', '2014-08-18', '2 x iPod Shuffle 2GB Yellow\n10 x iPod Shuffle 2GB Silver\n', 12, 0.00, '0000-00-00 00:00:00', 0),
(235, 1, 'V541', '2014-08-19', '3 x Lightning to USB Cable', 3, 0.00, '0000-00-00 00:00:00', 0),
(236, 1, 'V549', '2014-08-20', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(237, 1, 'V569', '2014-08-30', '45 x Lightning Cable\n10 x USB Adapter 12W', 55, 0.00, '0000-00-00 00:00:00', 0),
(238, 1, 'V575', '2014-08-30', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(239, 1, 'V576', '2014-08-30', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(240, 1, 'V584', '2014-08-30', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(241, 1, 'V585', '2014-09-09', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(242, 1, 'V591', '2014-09-13', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(243, 1, 'V593', '2014-09-15', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(244, 1, 'V596', '2014-09-16', '5 x EarPods', 5, 0.00, '0000-00-00 00:00:00', 0),
(245, 1, 'V598', '2014-09-16', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(246, 1, 'V601', '2014-09-20', '2 x iPhone 5S 16GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(247, 1, 'V606', '2014-09-23', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(248, 1, 'V608', '2014-09-25', '1 x iPhone 5S 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(249, 1, 'V609', '2014-09-25', '1 x iPad Air WiFi + Cell 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(250, 1, 'V616', '2014-09-29', '2 x 30 Pin Cable', 2, 0.00, '0000-00-00 00:00:00', 0),
(251, 1, 'V623', '2014-09-30', '4 x iPhone 5S 16GB Gold', 4, 0.00, '0000-00-00 00:00:00', 0),
(252, 1, 'V630', '2014-09-30', '20 x Lightning Cable\n5 x 30 Pin Cable', 25, 32.00, '0000-00-00 00:00:00', 0),
(253, 1, 'V631', '2014-10-10', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(254, 1, 'V632', '2014-10-10', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(255, 1, 'V636', '2014-10-15', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(256, 1, 'V662', '2014-10-17', '18 x iPhone 6 16GB Gold\n2 x iPhone 6 16GB Space Gray\n6 x iPhone 6 16GB Silver\n4 x iPhone 6 64GB Gold\n1 x iPhone 6 64GB Space Gray\n3 x iPhone 6 Plus 64GB Space Gray\n1 x iPhone 6 Plus 16GB Space Gray', 35, 0.00, '0000-00-00 00:00:00', 0),
(257, 1, 'V676', '2014-10-18', '1 x iPhone 6 16Gb Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(258, 1, 'V683', '2014-10-18', '1 x iPhone 6 Plus 64Gb Space Gray\n1 x iPhone 6 64Gb Gold\n1 x iPhone 6 16Gb Gold\n', 3, 1.00, '0000-00-00 00:00:00', 0),
(259, 1, 'V696', '2014-10-20', '1 x iPhone 5S 16GB Gold\n6 x iPhone 6 Plus 64GB Gold\n1 x iPhone 6 Plus 16GB Silver', 8, 0.00, '0000-00-00 00:00:00', 0),
(260, 1, 'V709', '2014-10-21', '1 x iPhone 6 16GB Gold\n2 x iPhone 6 Plus 16GB Gold\n1 x iPhone 6 Plus 16GB Silver\n', 4, 0.00, '0000-00-00 00:00:00', 0),
(261, 1, 'V727', '2014-10-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(262, 1, 'V732', '2014-10-24', '3 x iPad Air WiFi + Cell 16GB Space Gray\n1 x iPad Mini RD WiFi + Cell 16GB Silver\n2 x iPad Mini WiFi 16GB Space Gray', 6, 0.00, '0000-00-00 00:00:00', 0),
(263, 1, 'V733', '2014-10-24', '2 x iPhone 6 16GB Space Gray\n1 x iPhone 6 128GB Gold\n1 x iPhone 5S 16GB Gold\n\n', 4, 0.00, '0000-00-00 00:00:00', 0),
(264, 1, 'V748', '2014-10-29', '3 x iPhone 6 Plus 16Gb Gold\n1 x iPhone 6 Plus 16Gb Silver\n2 x iPhone 6 Plus 16Gb Space Gray\n1 x iPhone 6 16Gb Space Gray\n1 x iPhone 6 64Gb Space Gray\n', 8, 0.00, '0000-00-00 00:00:00', 0),
(265, 1, 'V758', '2014-10-30', '3 x 30 Pin to USB Cable', 3, 0.00, '0000-00-00 00:00:00', 0),
(266, 1, 'V759', '2014-10-30', '1 x iPhone 6 64Gb Space Gray\n1 x iPhone 6 Plus 128GB Silver', 2, 0.00, '0000-00-00 00:00:00', 0),
(267, 1, 'V776', '2014-11-01', '1 x iPhone 6 16GB Gold\n1 x iPhone 6 16GB Silver\n1 x iPhone 6 64GB Silver', 3, 0.00, '0000-00-00 00:00:00', 0),
(268, 1, 'V785', '2014-11-01', '1 x iPhone 5C Case Black\n1 x iPhone 5C Case Blue\n1 x iPhone 5C Case Green', 3, 0.00, '0000-00-00 00:00:00', 0),
(269, 1, 'V792', '2014-11-01', '1 x iPhone 6 Plus 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(270, 1, 'V794', '2014-11-03', '1 x iPhone 6 Plus 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(271, 1, 'V798', '2014-11-04', '1 x iPhone 6 Plus 64GB Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(272, 1, 'V814', '2014-11-05', '1 x iPhone 6 Plus 16GB Gold DEMO', 1, 0.00, '0000-00-00 00:00:00', 0),
(273, 1, 'V820', '2014-11-05', '3 x iPhone 6 16GB Gold\n2 x iPhone 6 16GB Space Gray\n1 x iPhone 6 Plus 64GB Space Gray', 6, 0.00, '0000-00-00 00:00:00', 0),
(274, 1, 'V828', '2014-11-05', '4 x iPhone 5C Case Black\n1 x iPhone 5C Case Blue', 5, 0.00, '0000-00-00 00:00:00', 0),
(275, 1, 'V833', '2014-11-06', '1 x iPhone 6 Plus 64GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(276, 1, 'V834', '2014-11-06', '3 x Lightning to USB Cable\n2 x USB Power Adapter', 5, 0.00, '0000-00-00 00:00:00', 0),
(277, 1, 'V839', '2014-11-07', '1 x iPhone 6 16GB Gold\n1 x iPhone 6 Plus 16GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(278, 1, 'V840', '2014-11-07', '1 x iPhone 5C Case White', 1, 0.00, '0000-00-00 00:00:00', 0),
(279, 1, 'V841', '2014-11-07', '1 x iPhone 6 Plus 64GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(280, 1, 'V848', '2014-11-08', '1 x iPhone 6 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(281, 1, 'V857', '2014-11-08', '1 x iPhone 6 64GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(282, 1, 'V862', '2014-11-12', '1 x iPhone 6 Plus 64GB Gold\n1 x iPhone 6 Plus 64GB Space Gray\n2 x iPhone 6 Plus 16GB Silver\n1 x iPhone 6 Plus 16GB Space Gray\n\n', 5, 0.00, '0000-00-00 00:00:00', 0),
(283, 1, 'V863', '2014-11-12', '2 x iPad Mini WiFi 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(284, 1, 'V864', '2014-11-12', '1 x iPhone 5S 16GB Space Gray\n1 x iPhone 5S 16GB Silver', 2, 0.00, '0000-00-00 00:00:00', 0),
(285, 1, 'V868', '2014-11-13', '50 x Lightning to USB Cable', 50, 0.00, '0000-00-00 00:00:00', 0),
(286, 1, 'V873', '2014-11-15', '3 x iPhone 6 64GB Space Gray\n5 x iPhone 5S 16GB Gold', 8, 0.00, '0000-00-00 00:00:00', 0),
(287, 1, 'V882', '2014-11-15', '1 x iPhone 6 Plus 64GB Silver', 1, 0.00, '0000-00-00 00:00:00', 0),
(288, 1, 'V894', '2014-11-15', '5 x iPhone 5S 16GB Gold', 5, 0.00, '0000-00-00 00:00:00', 0),
(289, 1, 'V901', '2014-11-18', '1 x iPhone 6 Plus 64GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(290, 1, 'V903', '2014-11-18', '1 x iPhone 6 128GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(291, 1, 'V909', '2014-11-18', '1 x iPhone 6 Plus 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(292, 1, 'V916', '2014-11-18', '2 x iPhone 6 16GB Gold\n6 x iPhone 6 16GB Space Gray\n2 x iPhone 4S 8GB White\n3 x iPhone 4S 8GB Black\n1 x iPhone 6 128GB Silver', 14, 0.00, '0000-00-00 00:00:00', 0),
(293, 1, 'V928', '2014-11-18', '1 x iPhone 6 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(294, 1, 'V944', '2014-11-22', '1 x iPhone 6 Plus 16GB Silver\n2 x iPhone 5S 16GB Silver\n1 x iPhone 6 16GB Gold\n1 x iPhone 6 16GB Space Gray', 5, 0.00, '0000-00-00 00:00:00', 0),
(295, 1, 'V953', '2014-11-24', '1 x iPhone 6 Plus 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(296, 1, 'V965', '2014-11-24', '1 x iPhone 6 16GB Gold\n2 x iPhone 6 64GB Silver\n2 x iPhone 6 16GB Space Gray\n1 x iPhone 6 64GB Gold\n2 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black\n1 x iPhone 6 Plus 64GB Gold\n1 x iPhone 6 Plus 16GB Gold', 11, 0.00, '0000-00-00 00:00:00', 0),
(297, 1, 'V983', '2014-11-24', '2 x iPhone 5S 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(298, 1, 'V990', '2014-11-24', '3 x iPhone 6 16GB Gold\n2 x iPhone 6 16GB Space Gray\n4 x iPhone 6 64GB Gold\n1 x iPhone 6 64GB Space Gray\n3 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black', 14, 0.00, '0000-00-00 00:00:00', 0),
(299, 1, 'V1027', '2014-12-03', '1 x iPhone 5S 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(300, 1, 'V1035', '2014-12-03', '1 x iPhone 6 Plus 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(301, 1, 'V1043', '2014-12-03', '1 x iPhone 6 16GB Space Gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(302, 1, 'V1057', '2014-12-03', '4 x iPhone 6 16GB Space Gray\n2 x iPhone 4S 8GB Black\n1 x iPhone 5S 16GB Gold', 7, 0.00, '0000-00-00 00:00:00', 0),
(303, 1, 'V1066', '2014-12-08', '3 x iPhone 5S 16GB Gold\n2 x iPhone 5S 16GB Space Gray\n1 x iPhone 5S 16GB Silver\n2 x iPhone 6 64GB Space Gray\n1 x iPhone 6 64GB Silver\n1 x iPhone 4S 8GB Black\n1 x iPhone 6 Plus 16GB Space Gray', 11, 0.00, '0000-00-00 00:00:00', 0),
(304, 1, 'V1074', '2014-12-09', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(305, 1, 'V1086', '2014-12-10', '5 x iPhone 6 16GB Gold', 5, 0.00, '0000-00-00 00:00:00', 0),
(306, 1, 'V1099', '2014-12-11', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(307, 1, 'V1110', '2014-12-12', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(308, 1, 'V1114', '2014-12-12', '1 x iPhone 16GB Space Gray Demo', 1, 0.00, '0000-00-00 00:00:00', 0),
(309, 1, 'V1130', '2014-12-12', '2 x iPhone 6 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(310, 1, 'V1131', '2014-12-12', '1 x iPad Air WiFi + Cell 16Gb Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(311, 1, 'V1139', '2014-12-12', '1 x iPhone 6 64Gb Space Gray\n2 x iPhone 6 64Gb Gold', 3, 0.00, '0000-00-00 00:00:00', 0),
(312, 1, 'V1141', '2014-12-17', '2 x iPhone 5S 16GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(313, 1, 'V1147', '2014-12-17', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(314, 1, 'V1152', '2014-12-18', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(315, 1, 'V1160', '2014-12-18', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(316, 1, 'V1163', '2014-12-20', '1 x iPhone 6 Plus 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(317, 1, 'V1175', '2014-12-22', '2 x iPhone 6 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(318, 1, 'V1176', '2014-12-22', '1 x iPhone 6 Plus 16GB Silver\n', 1, 0.00, '0000-00-00 00:00:00', 0),
(319, 1, 'V1184', '2014-12-23', '1 x iPhone 5S 16GB Gold\n1 x iPhone 6 Plus 16GB Gold', 1, 0.00, '0000-00-00 00:00:00', 0),
(320, 1, 'V1197', '2014-12-25', '1 x iPhone 5S 16GB Space gray', 1, 0.00, '0000-00-00 00:00:00', 0),
(321, 1, 'V1207', '2014-12-26', '2 x iPhone 6 16GB Space Gray', 2, 0.00, '0000-00-00 00:00:00', 0),
(322, 1, 'V1208', '2014-12-27', '2 x iPhone 6 64GB Gold\n1 x iPhone 6 Plus 16GB Gold\n1 x iPhone 6 128GB Silver\n2 x iPhone 5S 16GB Gold', 6, 0.00, '0000-00-00 00:00:00', 0),
(323, 1, 'V1214', '2014-12-29', '1 x iPhone 6 Plus 16GB Gold\n1 x iPhone 4S 8GB White\n1 x iPhone 6 16GB Space Gray\n1 x iPhone 6 64GB Space Gray', 4, 0.00, '0000-00-00 00:00:00', 0),
(324, 1, 'V1220', '2014-12-30', '2 x iPhone 5S 16GB Space Gray\n1 x iPhone 5S 16GB Silver\n2 x iPhone 6 16GB Space Gray\n1 x iPhone 6 64GB Space Gray\n1 x iPhone 6 64GB Gold', 7, 0.00, '0000-00-00 00:00:00', 0),
(325, 1, 'V1231', '2014-12-31', '2 x iPhone 5S 16GB Gold', 2, 0.00, '0000-00-00 00:00:00', 0),
(326, 1, 'V1236', '2014-12-31', '3 x iPhone 6 16GB Space Gray', 3, 0.00, '0000-00-00 00:00:00', 0),
(327, 1, 'V1243', '2015-01-02', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(328, 1, 'V1260', '2015-01-05', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(329, 1, 'V1262', '2015-01-05', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(330, 1, 'V1265', '2015-01-06', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(331, 1, 'V1268', '2015-01-06', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(332, 1, 'V1275', '2015-01-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(333, 1, 'V1288', '2015-01-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(334, 1, 'V1289', '2015-01-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(335, 1, 'V1303', '2015-01-13', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(336, 1, 'V1317', '2015-01-16', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(337, 1, 'V1320', '2015-01-16', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(338, 1, 'V1324', '2015-01-16', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(339, 1, 'V1327', '2015-01-19', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(340, 1, 'V1330', '2015-01-20', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(341, 1, 'V1336', '2015-01-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(342, 1, 'V1339', '2015-01-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(343, 1, 'V1356', '2015-01-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(344, 1, 'V1369', '2015-01-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(345, 1, 'V1372', '2015-01-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(346, 1, 'V1374', '2015-01-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(347, 1, 'V1376', '2015-01-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(348, 1, 'V1378', '2015-01-30', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(349, 1, 'V1383', '2015-01-30', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(350, 1, 'V1393', '2015-02-03', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(351, 1, 'V1416', '2015-02-03', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(352, 1, 'V1417', '2015-02-03', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(353, 1, 'V1426', '2015-02-03', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(354, 1, 'V1434', '2015-02-05', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(355, 1, 'V1435', '2015-02-05', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(356, 1, 'V1436', '2015-02-06', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(357, 1, 'V1440', '2015-02-06', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(358, 1, 'V1449', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(359, 1, 'V1456', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(360, 1, 'V1464', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(361, 1, 'V1470', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(362, 1, 'V1474', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(363, 1, 'V1480', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(364, 1, 'V1493', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(365, 1, 'V1499', '2015-02-07', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(366, 1, 'V1507', '2015-02-16', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(367, 1, 'V1513', '2015-02-16', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(368, 1, 'V1519', '2015-02-18', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(369, 1, 'V1531', '2015-02-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(370, 1, 'V1535', '2015-02-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(371, 1, 'V1542', '2015-02-21', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(372, 1, 'V1547', '2015-02-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(373, 1, 'V1550', '2015-02-24', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(374, 1, 'V1556', '2015-02-26', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(375, 1, 'V1560', '2015-02-26', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(376, 1, 'V1561', '2015-02-26', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(377, 1, 'V1565', '2015-02-26', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(378, 1, 'V1575', '2015-02-26', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(379, 1, 'V1578', '2015-03-02', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(380, 1, 'V1594', '2015-03-02', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(381, 1, 'V1615', '2015-03-02', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(382, 1, 'V1618', '2015-03-09', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(383, 1, 'V1624', '2015-03-09', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(384, 1, 'V1625', '2015-03-09', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(385, 1, 'V1633', '2015-03-11', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(386, 1, 'V1637', '2015-03-12', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(387, 1, 'V1645', '2015-03-12', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(388, 1, 'V1655', '2015-03-12', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(389, 1, 'V1695', '2015-03-31', '', 0, 0.00, '0000-00-00 00:00:00', 0),
(390, 1, 'V1696', '2015-03-31', '', 0, 0.00, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `distributors`
--

CREATE TABLE IF NOT EXISTS `distributors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `contactperson` varchar(64) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `tin` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `distributors`
--

INSERT INTO `distributors` (`id`, `name`, `contactperson`, `address`, `mobile`, `phone`, `email`, `tin`) VALUES
(1, 'Vision Telecommunications Pvt. Ltd.', 'Manmohan Swaraj', 'Vision Telecommunication India Pvt Ltd-Punjab\r\nOpp. Mayur Hotel, Behind Indian Overseas Bank, Zirakpur\r\nPunjab', '8591239007', '9988888950', 'manmohan@ksons.co.in', '03062151092'),
(2, 'BAMA Infotech', 'Gurdeep Singh', '14-D, Kitchlu Nagar, Opp. Lions Club, Ludhiana - 141 001, Punjab, India.', '8146321400', '01615031333', 'info@bamainfotech.com', '03051110336'),
(3, 'Dummy Distributor', 'BKM', 'Some place nice', '9', '12345677', '22bankim@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `problemsreportedtypes`
--

CREATE TABLE IF NOT EXISTS `problemsreportedtypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `problemsreportedtypes`
--

INSERT INTO `problemsreportedtypes` (`id`, `type`) VALUES
(2, 'Dock Related'),
(1, 'Earpiece Related');

-- --------------------------------------------------------

--
-- Table structure for table `productaccessories`
--

CREATE TABLE IF NOT EXISTS `productaccessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `productaccessories`
--

INSERT INTO `productaccessories` (`id`, `type`) VALUES
(2, 'Earphones'),
(1, 'Power Adapter');

-- --------------------------------------------------------

--
-- Table structure for table `productconditiontypes`
--

CREATE TABLE IF NOT EXISTS `productconditiontypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `productconditiontypes`
--

INSERT INTO `productconditiontypes` (`id`, `type`) VALUES
(2, 'Minor Dents & Scratches'),
(1, 'Minor Scuffs & Scratches');

-- --------------------------------------------------------

--
-- Table structure for table `productparts`
--

CREATE TABLE IF NOT EXISTS `productparts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parts` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `diagnosis` (`parts`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `productparts`
--

INSERT INTO `productparts` (`id`, `parts`) VALUES
(11, 'Bluetooth'),
(7, 'Digitiser/Display'),
(2, 'Earphone Jack'),
(9, 'Front Cam'),
(6, 'Home Button/Fingerprint Sensor'),
(5, 'Microphone'),
(8, 'Proximity Sensor'),
(10, 'Rear Camera'),
(1, 'Sleep/Wake Button Flex'),
(4, 'Speaker'),
(3, 'USB/Dock'),
(12, 'WiFi');

-- --------------------------------------------------------

--
-- Table structure for table `repairjobs`
--

CREATE TABLE IF NOT EXISTS `repairjobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inwarddate` datetime NOT NULL,
  `dateofdeposit` datetime NOT NULL,
  `dateofreturn` datetime NOT NULL,
  `outwarddate` datetime NOT NULL,
  `productmodelid` int(10) unsigned NOT NULL,
  `productserialnumber` varchar(128) NOT NULL,
  `dateofpurchase` date NOT NULL,
  `productconditionid` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobileno` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inwarddate` (`inwarddate`),
  KEY `productmodelid` (`productmodelid`),
  KEY `mobileno` (`mobileno`),
  KEY `productconditionid` (`productconditionid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `repairjobs`
--

INSERT INTO `repairjobs` (`id`, `inwarddate`, `dateofdeposit`, `dateofreturn`, `outwarddate`, `productmodelid`, `productserialnumber`, `dateofpurchase`, `productconditionid`, `name`, `address`, `mobileno`, `email`, `modified`, `modifiedby`) VALUES
(1, '2014-10-26 18:29:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '111231333313', '2014-10-26', 2, 'Bankim Bhagat', 'Prem Nagar', '', '22bankim@gmail.com', '2014-10-26 18:30:24', 0),
(2, '2014-10-27 01:37:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '11123133331311ssZ', '2014-10-27', 2, 'Bankim Bhagat', 'skds kdd', '99848848488', '22bankim@gmail.com', '2014-10-27 01:37:54', 0),
(3, '2014-10-27 03:18:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '11123133331311ssZ', '2014-10-27', 1, 'Bankim Bhagat', 'dlslsd', '999899888', '22bankim@gmail.com', '2014-10-27 03:19:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `viewallactionlog` tinyint(1) NOT NULL DEFAULT '0',
  `createusers` tinyint(1) NOT NULL DEFAULT '0',
  `changeownpassword` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `enabled`, `admin`, `viewallactionlog`, `createusers`, `changeownpassword`) VALUES
(1, 'Administrator', 1, 1, 1, 1, 1),
(2, 'View Reports', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `salesinvoice`
--

CREATE TABLE IF NOT EXISTS `salesinvoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoicedate` date NOT NULL,
  `customername` varchar(64) NOT NULL,
  `customermobile` varchar(12) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `modfied` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modifiedby` (`modifiedby`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `salesinvoiceitems`
--

CREATE TABLE IF NOT EXISTS `salesinvoiceitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `stockitemid` int(10) unsigned NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `rp` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salesinvoiceid` (`salesinvoiceid`,`stockitemid`),
  KEY `stockitemid` (`stockitemid`),
  KEY `salesinvoiceid_2` (`salesinvoiceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stockitems`
--

CREATE TABLE IF NOT EXISTS `stockitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stockitemtypeid` int(10) unsigned NOT NULL,
  `distributorinvoiceid` int(10) unsigned NOT NULL,
  `sku` varchar(64) NOT NULL,
  `barcode` varchar(256) NOT NULL,
  `itemname` varchar(64) NOT NULL,
  `bp` decimal(12,2) NOT NULL COMMENT 'Base price without tax',
  `taxrateid` int(3) unsigned NOT NULL,
  `description` text NOT NULL,
  `mrp` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1' COMMENT 'Quantity of Similar Items in Stock',
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stockitemtypeid` (`stockitemtypeid`),
  KEY `distributorinvoiceid` (`distributorinvoiceid`),
  KEY `salesinvoiceid` (`salesinvoiceid`),
  KEY `modifiedby` (`modifiedby`),
  KEY `barcode` (`barcode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `stockitems`
--

INSERT INTO `stockitems` (`id`, `stockitemtypeid`, `distributorinvoiceid`, `sku`, `barcode`, `itemname`, `bp`, `taxrateid`, `description`, `mrp`, `quantity`, `salesinvoiceid`, `modified`, `modifiedby`) VALUES
(2, 3, 2, 'MF352HN/A', '358840058253078', 'iPhone 5S 16GB Space Gray', 47043.43, 2, '', 53500.00, 10, 0, '2014-02-05 02:32:04', 0),
(3, 2, 2, 'MF354HN/A', '351984060332244', 'iPhone 5S 16GB Gold', 47043.43, 2, '', 53500.00, 5, 0, '2014-02-05 02:33:51', 0),
(4, 2, 2, 'MF354HN/A', '351980060983184', 'iPhone 5S 16GB Gold', 47043.43, 2, '', 53500.00, 1, 0, '2015-04-19 18:20:37', 0),
(5, 2, 2, 'MF354HN/A', '', 'iPhone 5S 16GB Gold', 47043.43, 2, '', 53500.00, 1, 0, '2015-05-02 02:17:59', 0),
(6, 2, 4, 'MF266HN/A', '', 'iPhone 4S 8GB White', 27698.22, 2, '', 31500.00, 1, 0, '2015-05-02 02:29:52', 0),
(7, 2, 4, 'MF266HN/A', '', 'iPhone 4S 8GB White', 27698.22, 2, '', 31500.00, 1, 0, '2015-05-02 02:29:52', 0),
(8, 26, 121, '', '359264062862940', '', 57155.92, 2, '', 65000.00, 1, 0, '2015-05-08 14:17:33', 0),
(9, 21, 122, '', '359251068330436', '', 49241.88, 2, '', 56000.00, 1, 0, '2015-05-08 14:19:15', 0),
(10, 209, 152, 'MD775HN/A', 'SCC4LJHCTF4RW', '', 2997.31, 1, '', 3700.00, 1, 0, '2015-05-17 18:57:49', 0),
(11, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '0000-00-00 00:00:00', 0),
(12, 245, 86, 'MD818ZM/A', '', 'Lightning to USB Cable', 1151.36, 1, '', 1500.00, 1, 0, '2015-06-03 00:41:16', 0),
(13, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2014-02-05 02:32:04', 0),
(14, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2014-02-05 02:33:51', 0),
(15, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-04-19 18:20:37', 0),
(16, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-02 02:17:59', 0),
(17, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-02 02:29:52', 0),
(18, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-02 02:29:52', 0),
(19, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-08 14:17:33', 0),
(20, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-08 14:19:15', 0),
(21, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-17 18:57:49', 0),
(22, 248, 108, 'MC265FC/E', '', 'Apple Protection Plan for iPhone', 3127.44, 4, '', 3900.00, 1, 0, '2015-05-17 18:57:49', 0),
(23, 245, 86, 'MD818ZM/A', '', 'Lightning to USB Cable', 1151.36, 1, '', 1500.00, 1, 0, '2015-06-03 00:41:16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stockitemtypes`
--

CREATE TABLE IF NOT EXISTS `stockitemtypes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentcategoryid` int(11) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`),
  KEY `parentcategoryid` (`parentcategoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=250 ;

--
-- Dumping data for table `stockitemtypes`
--

INSERT INTO `stockitemtypes` (`id`, `parentcategoryid`, `type`) VALUES
(1, 0, 'iPhone'),
(2, 1, '4 8GB Black'),
(3, 1, '4 8GB White'),
(4, 1, '4 16GB Black'),
(5, 1, '4 16GB White'),
(6, 1, ' 4S 8GB Black'),
(7, 1, '4S 8GB White'),
(8, 1, '5 16GB Slate Gray'),
(9, 1, '5 16GB Silver'),
(10, 1, '5 32GB Slate Gray'),
(11, 1, '5 32GB Silver'),
(12, 1, '5S 16GB Gold'),
(13, 1, '5S 16GB Space Gray'),
(14, 1, '5S 16GB Silver'),
(15, 1, '5S 32GB Gold'),
(16, 1, '5S 32GB Space Gray'),
(17, 1, '5S 32GB Silver'),
(18, 1, '5S 64GB Gold'),
(19, 1, '5S 64GB Space Gray'),
(20, 1, '5S 64GB Silver'),
(21, 1, '6 16GB Gold'),
(22, 1, '6 16GB Space Gray'),
(23, 1, '6 16GB Silver'),
(24, 1, '6 64GB Gold'),
(25, 1, '6 64GB Space Gray'),
(26, 1, '6 64GB Silver'),
(27, 1, '6 128GB Gold'),
(28, 1, '6 128GB Space Gray'),
(29, 1, '6 128GB Silver'),
(30, 1, '6 Plus 16GB Gold'),
(31, 1, '6 Plus 16GB Space Gray'),
(32, 1, '6 Plus 16GB Silver'),
(33, 1, '6 Plus 64GB Gold'),
(34, 1, '6 Plus 64GB Space Gray'),
(35, 1, '6 Plus 64GB Silver'),
(36, 1, '6 Plus 128GB Gold'),
(37, 1, '6 Plus 128GB Space Gray'),
(38, 1, '6 Plus 128GB Silver'),
(39, 0, 'iPad'),
(40, 39, 'Mini 16GB WiFi Gray'),
(41, 39, 'Mini 16GB WiFi Silver'),
(42, 39, 'Mini 16GB WiFi + Cell Gray'),
(43, 39, 'Mini 16GB WiFi + Cell Silver'),
(44, 39, 'Mini 32GB WiFi Gray'),
(45, 39, 'Mini 32GB WiFi Silver'),
(46, 39, 'Mini 32GB WiFi + Cell Gray'),
(47, 39, 'Mini 32GB WiFi + Cell Silver'),
(48, 39, 'Mini 64GB WiFi Gray'),
(49, 39, 'Mini 64GB WiFi Silver'),
(50, 39, 'Mini 64GB WiFi + Cell Gray'),
(51, 39, 'Mini 64GB WiFi + Cell Silver'),
(52, 39, 'Mini RD 16GB WiFi Gray'),
(53, 39, 'Mini RD 16GB WiFi Silver'),
(54, 39, 'Mini RD 16GB WiFi + Cell Gray'),
(55, 39, 'Mini RD 16GB WiFi + Cell Silver'),
(56, 39, 'Mini RD 32GB WiFi Gray'),
(57, 39, 'Mini RD 32GB WiFi Silver'),
(58, 39, 'Mini RD 32GB WiFi + Cell Gray'),
(59, 39, 'Mini RD 32GB WiFi + Cell Silver'),
(60, 39, 'Mini RD 64GB WiFi Gray'),
(61, 39, 'Mini RD 64GB WiFi Silver'),
(62, 39, 'Mini RD 64GB WiFi + Cell Gray'),
(63, 39, 'Mini RD 64GB WiFi + Cell Silver'),
(162, 39, 'Mini 3 16GB WiFi Gray'),
(163, 39, 'Mini 3 16GB WiFi Silver'),
(164, 39, 'Mini 3 16GB WiFi + Cell Gray'),
(165, 39, 'Mini 3 16GB WiFi + Cell Silver'),
(166, 39, 'Mini 3 64GB WiFi Gray'),
(167, 39, 'Mini 3 64GB WiFi Silver'),
(168, 39, 'Mini 3 64GB WiFi + Cell Gray'),
(169, 39, 'Mini 3 64GB WiFi + Cell Silver'),
(170, 39, 'Mini 3 128GB WiFi Gray'),
(171, 39, 'Mini 3 128GB WiFi Silver'),
(172, 39, 'Mini 3 128GB WiFi + Cell Gray'),
(173, 39, 'Mini 3 128GB WiFi + Cell Silver'),
(174, 39, 'Air 16GB WiFi Gray'),
(175, 39, 'Air 16GB WiFi Silver'),
(176, 39, 'Air 16GB WiFi + Cell Gray'),
(177, 39, 'Air 16GB WiFi + Cell Silver'),
(178, 39, 'Air 32GB WiFi Gray'),
(179, 39, 'Air 32GB WiFi Silver'),
(180, 39, 'Air 32GB WiFi + Cell Gray'),
(181, 39, 'Air 32GB WiFi + Cell Silver'),
(182, 39, 'Air 64GB WiFi Gray'),
(183, 39, 'Air 64GB WiFi Silver'),
(184, 39, 'Air 64GB WiFi + Cell Gray'),
(185, 39, 'Air 64GB WiFi + Cell Silver'),
(186, 39, 'Air 128GB WiFi Gray'),
(187, 39, 'Air 128GB WiFi Silver'),
(188, 39, 'Air 128GB WiFi + Cell Gray'),
(189, 39, 'Air 128GB WiFi + Cell Silver'),
(190, 39, 'Air 2 16GB WiFi Gray'),
(191, 39, 'Air 2 16GB WiFi Silver'),
(192, 39, 'Air 2 16GB WiFi Gold'),
(193, 39, 'Air 2 16GB WiFi + Cell Gray'),
(194, 39, 'Air 2 16GB WiFi + Cell Silver'),
(195, 39, 'Air 2 16GB WiFi + Cell Gold'),
(196, 39, 'Air 2 64GB WiFi Gray'),
(197, 39, 'Air 2 64GB WiFi Silver'),
(198, 39, 'Air 2 64GB WiFi Gold'),
(199, 39, 'Air 2 64GB WiFi + Cell Gray'),
(200, 39, 'Air 2 64GB WiFi + Cell Silver'),
(201, 39, 'Air 2 64GB WiFi + Cell Gold'),
(202, 39, 'Air 2 128GB WiFi Gray'),
(203, 39, 'Air 2 128GB WiFi Silver'),
(204, 39, 'Air 2 128GB WiFi Gold'),
(205, 39, 'Air 2 128GB WiFi + Cell Gray'),
(206, 39, 'Air 2 128GB WiFi + Cell Silver'),
(207, 39, 'Air 2 128GB WiFi + Cell Gold'),
(208, 0, 'iPod'),
(209, 208, 'Shuffle 2GB Blue'),
(210, 208, 'Shuffle 2GB Pink'),
(211, 208, 'Shuffle 2GB Purple'),
(212, 208, 'Shuffle 2GB Silver'),
(213, 208, 'Shuffle 2GB Gray'),
(214, 208, 'Shuffle 2GB Green'),
(215, 208, 'Shuffle 2GB Yellow'),
(216, 208, 'Nano 16GB Blue'),
(217, 208, 'Nano 16GB Pink'),
(218, 208, 'Nano 16GB Purple'),
(219, 208, 'Nano 16GB Silver'),
(220, 208, 'Nano 16GB Gray'),
(221, 208, 'Nano 16GB Green'),
(222, 208, 'Nano 16GB Yellow'),
(223, 208, 'Classic 160GB Black'),
(224, 208, 'Classic 160GB White'),
(225, 208, 'iPod Touch 5th Gen 32GB Blue'),
(226, 208, 'iPod Touch 5th Gen 32GB Pink'),
(227, 208, 'iPod Touch 5th Gen 32GB Purple'),
(228, 208, 'iPod Touch 5th Gen 32GB Silver'),
(229, 208, 'iPod Touch 5th Gen 32GB Gray'),
(230, 208, 'iPod Touch 5th Gen 32GB Green'),
(231, 208, 'iPod Touch 5th Gen 32GB Yellow'),
(232, 0, 'Accessories'),
(233, 232, '30 Pin to USB Cable'),
(234, 232, 'AirPort Express'),
(235, 232, 'Apple EarPods'),
(236, 232, 'Apple Keyboard with Numeric Keyp'),
(237, 232, 'Apple Lightning to 30-pin Adapte'),
(238, 232, 'Apple Magic Mouse'),
(239, 232, 'Apple Magic TrackPad'),
(240, 232, 'Apple Wireless Keyboard'),
(241, 232, 'iPhone 5C Cover'),
(242, 232, 'iPhone 5C Dock'),
(243, 232, 'iPhone 5S Cover'),
(244, 232, 'iPhone 5S Dock'),
(245, 232, 'Lightning to USB Cable'),
(246, 232, 'USB Power Adapter 12W'),
(247, 232, 'USB Power Adapter 5W'),
(248, 232, 'Apple Protection Plan for iPhone'),
(249, 232, 'Apple Protection Plan for iPad');

-- --------------------------------------------------------

--
-- Table structure for table `taxrates`
--

CREATE TABLE IF NOT EXISTS `taxrates` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(64) NOT NULL,
  `taxrate` decimal(4,2) NOT NULL,
  `validfrom` date NOT NULL COMMENT 'Date rate applicable',
  `validto` date NOT NULL COMMENT 'Date rate applicable upto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Tax rates applicable' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `taxrates`
--

INSERT INTO `taxrates` (`id`, `description`, `taxrate`, `validfrom`, `validto`) VALUES
(1, '13% - Accessory and iPod', 14.30, '2013-04-01', '2016-03-31'),
(2, '8.5% - Phones', 9.35, '2013-04-01', '2016-03-31'),
(3, '5.5% - IT Products', 6.05, '2015-04-01', '2016-03-31'),
(4, '12.35% - Service Tax', 12.35, '2015-04-01', '2016-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `local` varchar(10) NOT NULL DEFAULT 'en',
  `role` tinyint(1) NOT NULL DEFAULT '0',
  `mod_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `lastlogin`, `enabled`, `local`, `role`, `mod_datetime`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2015-06-17 19:12:32', 1, 'en', 1, '2009-04-20 14:08:40');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `salesinvoiceitems`
--
ALTER TABLE `salesinvoiceitems`
  ADD CONSTRAINT `salesinvoiceitems_ibfk_1` FOREIGN KEY (`salesinvoiceid`) REFERENCES `salesinvoice` (`id`),
  ADD CONSTRAINT `salesinvoiceitems_ibfk_2` FOREIGN KEY (`stockitemid`) REFERENCES `stockitems` (`id`);

--
-- Constraints for table `stockitems`
--
ALTER TABLE `stockitems`
  ADD CONSTRAINT `stockitems_ibfk_1` FOREIGN KEY (`stockitemtypeid`) REFERENCES `stockitemtypes` (`id`),
  ADD CONSTRAINT `stockitems_ibfk_2` FOREIGN KEY (`distributorinvoiceid`) REFERENCES `distributorinvoices` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
